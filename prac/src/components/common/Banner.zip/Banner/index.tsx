import React from "react"
import Image from "next/image"
import Styles from "./banner.module.css"
import Button from "../Button"
import moduleName from 'module'
import s1 from "@/public/images/slider1.jpg";
import s2 from "@/public/images/slider1.jpg";
import s3 from "@/public/images/slider1.jpg";
import b2 from "@/public/images/banner2.jpg";
import b3 from "@/public/images/banner3.jpg";
import slash from "@/public/images/slash.png";
import { BannerPropsType } from "@/utils/types"

const Banner = ({ data }: BannerPropsType) => {
  return (
    <div className=" grid grid-cols-1 gap-6 justify-self-center mx-5  lg:grid-cols-2 lg:mx-8 ">
      <div className="relative row-span-2">
        <Image alt="banner" className="select-none" src={s1} />
        <div className="absolute text-sm md:flex bottom-5 hidden left-8">
          <p className="px-6">Plants</p>
          <p className="px-6 border-l-[1px] border-black">Terrasium</p>
          <p className="px-6 border-l-[1px] border-black">Succulent</p>
        </div>
        <div className="absolute bottom-0 px-2 justify-center items-center bg-[#fefefe] right-0 flex flex-col">
          <p className="pt-5">01</p>
          <Image className="px-2" src={slash} alt="divider" />
          <p className="pb-5">03</p>
        </div>
      </div>
      <div className="relative group overflow-hidden">
        <Image
          className=" select-none group-hover:scale-105 transition-all"
          alt="banner"
          src={b2}
        />
        <div className="absolute top-[35%] bottom-[20%] w-44 md:w-48 lg:w-52 left-[60%] right-[10%] ">
          <strong className="lg:text-2xl md:text-2xl text-xl ">
            Snake Plant Laurentii Small
          </strong>
          <p className="text-base lg:text-xl ">$49.00</p>
        </div>
        <div className="bg-shimmer-banner group-hover:opacity-100"></div>
      </div>
      <div className="relative">
        <Image alt="banner" className="select-none" src={b3} />
        <div className="absolute top-12 md:top-14 md:w-52  lg:top-24 lg:left-8  lg:w-72 right-[20%] gap-4 w-44 flex flex-col left-4">
          <strong className="md:text-xl text-base lg:text-2xl">
            Peperomia Ripple Ruby Large
          </strong>
          <span className="text-base md:text-lg lg:text-xl">
            {" "}
            <b> $25.00 </b> <s>$39.00</s>{" "}
          </span>
        </div>
      </div>
    </div>
  )
}

export default Banner

{
  /* <section className={Styles.gridSection}>
      <div className={Styles.contentWrapper}>
        <div className={Styles.content}>
          <h2 className={Styles.heading}>{data.heading}</h2>
          {data.description && (
            <p className={Styles.description}>&quot;{data.description}&quot;</p>
          )}
        </div>
        <div className={Styles.bannerButtons}>
          {data.actionBtn1 && (
            <Button
              variant="fill"
              color="yellow"
              as="a"
              href={"#top-products"}
              className="!rounded-full"
            >
              {data.actionBtn1}
            </Button>
          )}
          {data.actionBtn2 && (
            <Button
              variant="outlined"
              color="light"
              as="a"
              href={"/products"}
              className="!rounded-full"
            >
              {data.actionBtn2}
            </Button>
          )}
        </div>
      </div>
      {data.backgroundBannerImage && (
        <div className={Styles.backgroundBannerImage}>
          <Image
            src={data.backgroundBannerImage}
            alt={"Banner Image"}
            fill
            style={{ objectFit: "contain" }}
            className="z-10"
          />
        </div>
      )}
    </section> */
}
